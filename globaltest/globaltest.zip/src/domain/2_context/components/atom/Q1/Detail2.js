const ContextQ1Detail2 = ({ onSetModalChange, text }) => {
  return (
    <>
      <h2>ContextQ1Detail2</h2>
      <button onClick={onSetModalChange}>{text}</button>
    </>
  );
};
export default ContextQ1Detail2;
