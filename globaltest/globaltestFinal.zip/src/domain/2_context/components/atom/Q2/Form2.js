const ContextQ2Form2 = ({ onAddIsEditUserList }) => {
  return (
    <div>
      <h1>Q2Form2</h1>
      <button onClick={onAddIsEditUserList}>STATUS 추가</button>
    </div>
  );
};
export default ContextQ2Form2;
