import styled from "styled-components";

function Second() {

    return(
        <S.Wrapper>IMG</S.Wrapper>
    )
}
export default Second;

const Wrapper = styled.header`

    width: 100%;
    height: 40vh;
    background-color: #8C8CBE;
`;

const S = {
    Wrapper,
}