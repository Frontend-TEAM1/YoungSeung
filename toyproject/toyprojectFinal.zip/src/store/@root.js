import { combineReducers } from "redux";
import posts from './post'

export const rootReducer = combineReducers({posts});