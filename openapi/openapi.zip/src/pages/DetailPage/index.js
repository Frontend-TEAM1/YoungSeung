function DetailPage() {
	// const a = useParams();
	// console.log(a);
	return <>:)</>;
}

export default DetailPage;
