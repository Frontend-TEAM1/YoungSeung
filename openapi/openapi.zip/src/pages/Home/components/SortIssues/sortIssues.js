function SortIssues() {
	return (
		<>
			<div>이슈정렬</div>
		</>
	);
}
export default SortIssues;
