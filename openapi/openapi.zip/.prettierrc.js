module.exports = {
	endOfLine: 'lf',
	semi: true,
	singleQuote: true,
	jsxSingleQuote: false,
	tabWidth: 2,
	useTabs: true,
	trailingComma: 'all',
	arrowParens: 'avoid',
}
